import { STAGE_WIDTH, STAGE_HEIGHT } from '../constants';
import { Player, StageData } from '../types';

// 空のステージ（盤面）を作成する関数
export const createStage = (): StageData =>
  Array.from(Array(STAGE_HEIGHT), () =>
    new Array(STAGE_WIDTH).fill([0, 'clear'])
  );

// 衝突判定を行う関数
export const checkCollision = (
  player: Player,
  stage: StageData,
  { x: moveX, y: moveY }: { x: number; y: number }
): boolean => {
  for (let y = 0; y < player.tetromino.length; y += 1) {
    for (let x = 0; x < player.tetromino[y].length; x += 1) {
      // 1. テトリミノのセルが空でないか確認（ブロックがある部分だけ判定）
      if (player.tetromino[y][x] !== 0) {
        if (
          // 2. ステージの高さ（Y軸）の範囲内か確認
          !stage[y + player.pos.y + moveY] ||
          // 3. ステージの幅（X軸）の範囲内か確認
          !stage[y + player.pos.y + moveY][x + player.pos.x + moveX] ||
          // 4. 移動先のセルが 'clear'（空）でないか確認（既にブロックがあるか）
          stage[y + player.pos.y + moveY][x + player.pos.x + moveX][1] !== 'clear'
        ) {
          return true; // 衝突あり
        }
      }
    }
  }
  return false; // 衝突なし
};
