import React from 'react';
import { TETROMINOS } from '../constants';
import { TetrominoType } from '../types';

interface CellProps {
  type: TetrominoType;
  isFlashing?: boolean;
}

// React.memoを使って不要な再レンダリングを防ぐ
const Cell: React.FC<CellProps> = React.memo(({ type, isFlashing }) => {
  const color = TETROMINOS[type] ? TETROMINOS[type].color : '0, 0, 0';
  const isFilled = type !== 0;

  // 点滅中は強制的に白くする
  const cellStyle = isFlashing 
    ? {
        background: 'white',
        border: 'none',
      }
    : {
        background: isFilled 
          ? `rgba(${color}, 0.8)` 
          : 'rgba(0, 0, 0, 0.3)',
        borderTop: isFilled ? `4px solid rgba(255,255,255,0.3)` : 'none',
        borderLeft: isFilled ? `4px solid rgba(255,255,255,0.3)` : 'none',
        borderRight: isFilled ? `4px solid rgba(0,0,0,0.1)` : '1px solid rgba(255,255,255,0.05)',
        borderBottom: isFilled ? `4px solid rgba(0,0,0,0.5)` : '1px solid rgba(255,255,255,0.05)',
      };

  return (
    <div
      className={`w-full h-full aspect-square border-b border-r border-white/10 ${
        isFilled ? 'shadow-sm' : ''
      } ${isFlashing ? 'animate-flash' : ''}`}
      style={cellStyle}
    />
  );
});

export default Cell;