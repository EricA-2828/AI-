import React from 'react';
import { TetrominoType } from '../types';
import { TETROMINOS } from '../constants';
import Cell from './Cell';

interface NextBlockProps {
  type: TetrominoType;
  label?: string;
  disabled?: boolean;
}

const NextBlock: React.FC<NextBlockProps> = React.memo(({ type, label = "NEXT", disabled = false }) => {
  // typeが0の場合はプレースホルダーを表示
  const shape = type !== 0 ? TETROMINOS[type].shape : [[0]];
  
  // 空の場合は適当なサイズを確保するためのダミー
  const gridRows = type !== 0 ? shape.length : 4;
  const gridCols = type !== 0 ? shape[0].length : 4;

  return (
    <div className={`bg-gray-900 p-4 rounded border border-gray-700 flex flex-col items-center justify-center min-h-[120px] ${disabled ? 'opacity-50 grayscale' : ''}`}>
      <p className="text-gray-400 text-xs mb-2 font-pixel">{label}</p>
      {type !== 0 ? (
        <div 
          className="grid gap-px bg-gray-900"
          style={{
              // グリッドのサイズを形状配列の大きさに合わせる
              gridTemplateColumns: `repeat(${gridCols}, 1fr)`,
              width: `${gridCols * 20}px` 
          }}
        >
          {shape.map((row, y) =>
            row.map((cell, x) => (
               <div key={`${y}-${x}`} style={{ width: '20px', height: '20px' }}>
                 {cell !== 0 ? <Cell type={type} /> : <div className="w-full h-full bg-transparent" />}
               </div>
            ))
          )}
        </div>
      ) : (
        <div className="text-gray-600 text-[10px] h-[60px] flex items-center justify-center">EMPTY</div>
      )}
    </div>
  );
});

export default NextBlock;