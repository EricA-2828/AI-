import { useEffect, useRef } from 'react';

// Dan AbramovによるuseIntervalの実装
// Reactのライフサイクル内でsetIntervalを安全に使うためのカスタムフック
export function useInterval(callback: () => void, delay: number | null) {
  // Fix: Initialize useRef with callback to satisfy argument requirement
  const savedCallback = useRef<() => void>(callback);

  // 最新のコールバックを保存
  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  // 間隔をセットアップ
  useEffect(() => {
    function tick() {
      if (savedCallback.current) {
        savedCallback.current();
      }
    }
    if (delay !== null) {
      const id = setInterval(tick, delay);
      return () => clearInterval(id);
    }
  }, [delay]);
}