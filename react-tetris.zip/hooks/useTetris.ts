import { useState, useCallback, useRef, useEffect } from 'react';
import { createStage, checkCollision } from '../utils/gameUtils';
import { TETROMINOS, STAGE_WIDTH, randomTetromino } from '../constants';
import { Player, StageData, TetrominoType } from '../types';

// 7種類のブロックをシャッフルして配列として返す関数（7-bag system）
const generateRandomBag = (): TetrominoType[] => {
  const tetrominos: TetrominoType[] = ['I', 'J', 'L', 'O', 'S', 'T', 'Z'];
  // Fisher-Yates Shuffle
  for (let i = tetrominos.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [tetrominos[i], tetrominos[j]] = [tetrominos[j], tetrominos[i]];
  }
  return tetrominos;
};

export const useTetris = () => {
  // ゲームの状態
  const [dropTime, setDropTime] = useState<number | null>(null);
  const [gameOver, setGameOver] = useState(false);
  const [isGameStarted, setIsGameStarted] = useState(false);
  const [score, setScore] = useState(0);
  const [rowsCleared, setRowsCleared] = useState(0);
  const [level, setLevel] = useState(0);
  
  // アニメーション用の状態: 消去中の行インデックスの配列
  const [clearingRows, setClearingRows] = useState<number[]>([]);

  // ホールド機能の状態
  const [holdTetromino, setHoldTetromino] = useState<TetrominoType>(0);
  const [canHold, setCanHold] = useState(true);

  // ハイスコアの状態
  const [highScores, setHighScores] = useState<number[]>([]);

  // 次のブロックの状態
  const [nextTetromino, setNextTetromino] = useState<TetrominoType>(0);

  // テトリミノの出現順序を管理するバッグ
  const bagRef = useRef<TetrominoType[]>([]);

  // プレイヤー（操作中のブロック）の状態
  const [player, setPlayer] = useState<Player>({
    pos: { x: 0, y: 0 },
    tetromino: TETROMINOS[0].shape,
    collided: false,
    type: 0,
  });

  // ステージ（盤面）の状態
  const [stage, setStage] = useState<StageData>(createStage());

  // 初回ロード時にハイスコアを読み込む
  useEffect(() => {
    const savedScores = localStorage.getItem('tetris-highscores');
    if (savedScores) {
      setHighScores(JSON.parse(savedScores));
    }
  }, []);

  // ゲームオーバー時にハイスコアを保存する
  useEffect(() => {
    if (gameOver) {
      setHighScores((prevScores) => {
        const newScores = [...prevScores, score]
          .sort((a, b) => b - a)
          .slice(0, 5);
        localStorage.setItem('tetris-highscores', JSON.stringify(newScores));
        return newScores;
      });
    }
  }, [gameOver, score]);

  // バッグから次のテトリミノを取得するヘルパー関数
  const getNextFromBag = useCallback(() => {
    if (bagRef.current.length === 0) {
      bagRef.current = generateRandomBag();
    }
    return bagRef.current.pop()!;
  }, []);

  const rotate = (matrix: (TetrominoType | 0)[][], dir: number) => {
    const rotatedTetro = matrix.map((_, index) =>
      matrix.map((col) => col[index])
    );
    if (dir > 0) return rotatedTetro.map((row) => row.reverse());
    return rotatedTetro.reverse();
  };

  const playerRotate = (stage: StageData, dir: number) => {
    const clonedPlayer = JSON.parse(JSON.stringify(player));
    clonedPlayer.tetromino = rotate(clonedPlayer.tetromino, dir);

    const pos = clonedPlayer.pos.x;
    let offset = 1;
    while (checkCollision(clonedPlayer, stage, { x: 0, y: 0 })) {
      clonedPlayer.pos.x += offset;
      offset = -(offset + (offset > 0 ? 1 : -1));
      if (offset > clonedPlayer.tetromino[0].length) {
        rotate(clonedPlayer.tetromino, -dir);
        clonedPlayer.pos.x = pos;
        return;
      }
    }
    setPlayer(clonedPlayer);
  };

  const updatePlayerPos = ({ x, y, collided }: { x: number; y: number; collided: boolean }) => {
    setPlayer((prev) => ({
      ...prev,
      pos: { x: (prev.pos.x += x), y: (prev.pos.y += y) },
      collided,
    }));
  };

  // プレイヤーのリセット（新しいブロックを出現させる）
  const resetPlayer = useCallback(() => {
    let currentType = nextTetromino;
    
    if (currentType === 0) {
       currentType = getNextFromBag();
    }

    const nextType = getNextFromBag();
    setNextTetromino(nextType);
    setCanHold(true); // 新しいターンなのでホールド可能にリセット

    setPlayer({
      pos: { x: STAGE_WIDTH / 2 - 2, y: 0 },
      tetromino: TETROMINOS[currentType].shape,
      collided: false,
      type: currentType,
    });
  }, [nextTetromino, getNextFromBag]);

  // ゲームのリセット
  const resetGame = () => {
    setStage(createStage());
    setGameOver(false);
    setIsGameStarted(true);
    setScore(0);
    setRowsCleared(0);
    setLevel(0);
    setClearingRows([]);
    setHoldTetromino(0); // ホールドのリセット
    setCanHold(true);
    
    bagRef.current = generateRandomBag();
    
    const firstType = getNextFromBag();
    const secondType = getNextFromBag();
    
    setPlayer({
      pos: { x: STAGE_WIDTH / 2 - 2, y: 0 },
      tetromino: TETROMINOS[firstType].shape,
      collided: false,
      type: firstType,
    });
    setNextTetromino(secondType);

    setDropTime(1000);
  };

  // ホールド機能
  const hold = () => {
    if (!canHold || gameOver || !isGameStarted) return;

    if (holdTetromino === 0) {
      // まだホールドがない場合
      setHoldTetromino(player.type);
      resetPlayer();
    } else {
      // すでにホールドがある場合：交換
      const currentType = player.type;
      const newType = holdTetromino;
      
      setHoldTetromino(currentType);
      setPlayer({
        pos: { x: STAGE_WIDTH / 2 - 2, y: 0 },
        tetromino: TETROMINOS[newType].shape,
        collided: false,
        type: newType,
      });
      setCanHold(false); // このターンはもうホールドできない
    }
  };

  const drop = () => {
    if (clearingRows.length > 0) return;

    if (rowsCleared > (level + 1) * 10) {
      setLevel((prev) => prev + 1);
      setDropTime(Math.max(100, 1000 - (level + 1) * 100)); 
    }

    if (!checkCollision(player, stage, { x: 0, y: 1 })) {
      updatePlayerPos({ x: 0, y: 1, collided: false });
    } else {
      if (player.pos.y < 1) {
        setGameOver(true);
        setIsGameStarted(false);
        setDropTime(null);
      }
      updatePlayerPos({ x: 0, y: 0, collided: true });
    }
  };

  const flushRows = useCallback((currentStage: StageData) => {
    let removedCount = 0;
    
    const newStage = currentStage.reduce((ack, row, idx) => {
      if (clearingRows.includes(idx)) {
        removedCount++;
        ack.unshift(new Array(currentStage[0].length).fill([0, 'clear']));
        return ack;
      }
      ack.push(row);
      return ack;
    }, [] as StageData);

    if (removedCount > 0) {
      setRowsCleared((prev) => prev + removedCount);
      const lineScores = [0, 40, 100, 300, 1200];
      const points = lineScores[removedCount] * (level + 1);
      setScore((prev) => prev + points);
    }

    setClearingRows([]);
    setStage(newStage);
  }, [clearingRows, level]);

  return {
    stage,
    setStage,
    player,
    setPlayer,
    rotate,
    playerRotate,
    updatePlayerPos,
    resetPlayer,
    resetGame,
    drop,
    dropTime,
    setDropTime,
    gameOver,
    isGameStarted,
    score,
    level,
    rowsCleared,
    flushRows,
    clearingRows,
    setClearingRows,
    nextTetromino,
    highScores,
    holdTetromino,
    hold,
    canHold
  };
};